import java.rmi.Naming;

import javax.swing.JOptionPane;

public class CalculatorCliente {
	public static void main(String []args) {
		
		try {
			Calculator c=(Calculator)Naming.lookup("//127.0.0.1:1999/CalculatorService"	);
			//JOptionPane.showInputDialog("addtion:"+c.add(10,15));
			System.out.println("addtion:"+c.add(10,15));
		}
		catch(Exception e)
		{	
			//JOptionPane.showMessageDialog(null, e);
			System.out.println(e);
			
			
		}
		
	}

}
