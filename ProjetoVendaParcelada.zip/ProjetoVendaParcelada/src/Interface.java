import java.rmi.Remote;
import java.rmi.RemoteException;

public interface Interface extends Remote { // Remote - m�todos podem ser chamados a partir de outra m�quina
	
	int controlador()throws RemoteException;
	
	public float getValor() throws RemoteException; //exce��o verificada - condi��es inv�lidas na entrada dos usu�rios
	public void setValor(float valor) throws RemoteException;
	
	public int getParcelas() throws RemoteException;
	public void setParcelas(int parcelas) throws RemoteException;
	
	public float getJuros() throws RemoteException;
	public void setJuros(float juros) throws RemoteException;
	
	public float getDesconto() throws RemoteException;
	public void setDesconto(float desconto) throws RemoteException;
	
	public float calcula() throws RemoteException;
	
	public float Valor() throws RemoteException;
	public float Valor2() throws RemoteException;
	
	public void zerar() throws RemoteException;
	
	public String Criptografia (String aux) throws RemoteException;
	public String Descriptografia (String aux) throws RemoteException;
	
}
