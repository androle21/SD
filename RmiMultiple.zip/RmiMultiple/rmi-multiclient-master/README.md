# rmi-multiclient
Java RMI (Remote Method Invocation) with multiple college clients. 

College sends top 10 students of their college. Server send result as top 5 students overall.
It needs data from atleast 10 clients. 10 Clients can be run by using 10 different cmd.
