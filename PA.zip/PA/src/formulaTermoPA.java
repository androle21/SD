
import javax.swing.JOptionPane;

public class formulaTermoPA {

    public static void main(String[] args) {

        /* Progama para fazer o caculo do valor de uma PA - Progressao Aritmetica, Matematica 2º Ensino Medio. 
        
         Questao: 
        
         ENCONTRE O CENTESIMO TERMO DA P.A (3,7,11): 
        
         r = Razao 
         a1 = Primeiro termo
         N = valor do centesimo termo
         aN = a1 + (n -1).r  -- Formula do termo geral de uma PA 
                 
         */
    	//int a1 = 3;
    	int a1 = Integer.parseInt(JOptionPane.showInputDialog("Informe o Primeiro termo da P.A:"));
    	    	
       // int r = 4; // 7 - 3 = 4
    	int r = Integer.parseInt(JOptionPane.showInputDialog("Informe a Razao da P.A:"));
     	
        //int n = 100;
    	int n = Integer.parseInt(JOptionPane.showInputDialog("Informe o valor do termo:"));

        int aN = a1 + (n - 1) * r;

        JOptionPane.showMessageDialog(
                null, "Encontre o Centesimo Termo da P.A (3, 7, 11)\n"
                + "O valor do centesimo termo é :  " + aN);

    }
}
