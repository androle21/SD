//https://pt.slideshare.net/java2all/java-rmi-example-program-with-code

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface Calculator extends Remote {
	public long add(long a, long b) throws RemoteException;

}
