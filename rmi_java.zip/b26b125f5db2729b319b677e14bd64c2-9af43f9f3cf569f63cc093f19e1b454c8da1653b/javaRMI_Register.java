package javaRMI;

import java.rmi.Remote;
import java.rmi.RemoteException;


/**
 * Created by omar on 8/17/18.
 */
public interface Register extends Remote {
    String getFirstName()throws RemoteException;
    void setFirstName(String firstName)throws RemoteException;
    String getLastName() throws RemoteException;
    void setLastName(String lastName)throws RemoteException;
    int getAge()throws RemoteException;
    void setAge(int age)throws RemoteException;
}